import { Injectable } from '@angular/core';
import { Userrole } from '../models/userrole';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor() { }

  authenticate(){
    //not implemented yet
  }
  //authentication logic
  //will decide whether user is logged or not 
  //will get to know role and can be used to return in getROle()

  isUserLoggedIn(){
    return true
  }
  getRole(){
    return Userrole.ROLE_ADMIN
  }
}
