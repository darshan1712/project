export class Users {
    id
    name
    email
}
